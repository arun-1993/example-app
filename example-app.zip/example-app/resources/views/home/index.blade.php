@extends('layouts.app')

@section('title', 'Index')

@section('content')
<h1>Welcome To Laravel!</h1>
<p>This is the content of the home page.</p>
@endsection