@extends('layouts.app')

@section('title', 'Contact')

@section('content')
<h1>Secret Page</h1>
<p>This is a secret email. <email>secret@laravel.test</email></p>
@endsection