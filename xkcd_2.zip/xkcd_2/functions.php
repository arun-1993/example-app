<?php

/**
 * Sends an email using the email id info.autotrackindia@gmail.com with the subject and content passed to the function.
 *
 * @param string $email The email address of the recipient.
 * @param string $html_content The content of the email to be sent along with the html tags needed for formatting the email.
 * @return string|null Null indicates the email has been successfully sent. Returns an error message if unsuccessful.
 */
function sendMail(string $email): ?string
{
    $subject = 'Verification for your subscription to daily dose of comics.';
    $message = 'This is a placeholder message for testing';

    return mail($email, $subject, $message);
}

/**
 * Pass a url to make an API call to and get the response in an array.
 *
 * @param string $request_url The URL to make the API call to.
 * @return array|null Null indicates that the API call was unsuccessful. Return a json decoded array of the response if successful.
 */
function apiCall(string $request_url): ?array
{
    $curl = curl_init($request_url);

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    if (!$response) {
        return null;
    }

    return json_decode($response, true);
}
