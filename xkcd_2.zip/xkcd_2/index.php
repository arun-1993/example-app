<?php require_once 'db_connection.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Dose of Comics</title>
</head>

<?php

if ('POST' === $_SERVER['REQUEST_METHOD'] && isset($_POST['subscribe'])) {
    $input  = $_POST['email'];
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    if ($input === $email && filter_var($input, FILTER_VALIDATE_EMAIL)) {
        $query = "INSERT INTO subscribers (email) VALUES (?)";

        $stmt = $mysqli->prepare($query);
        $stmt->bind_param('s', $email);
        $stmt->execute();

        if (1 === $stmt->affected_rows) {
            header("Location: verify.php?email=$email");
        } else {
            if (1062 === $stmt->errno) {
                echo 'Already subscribed!';
            } else {
                echo 'There was an error. Please try again after some time.';
            }
        }
    } else {
        echo 'Please enter a valid email address';
    }
}

?>

<body>
    <form method="POST">
        <label for="email">Subscribe Now For Your Daily Dose Of Comics! </label>
        <input type="email" name="email" placeholder="Enter your email" minlength="5" maxlength="255" required />
        <input type="submit" name="subscribe" value="Subscribe" />
    </form>
</body>
</html>