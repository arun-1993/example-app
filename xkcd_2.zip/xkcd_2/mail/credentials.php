<?php

$url = 'https://jsonplaceholder.typicode.com';
$collection = 'users';
$request_url = $url. '/'. $collection;

$curl = curl_init($request_url);

curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, [
   'Content-Type: application/json'
]);

$response = curl_exec($curl);
curl_close($curl);

echo "<pre>";
print_r(json_decode($response, true));
echo "</pre>";