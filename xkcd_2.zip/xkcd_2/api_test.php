<?php

require_once 'header.php';

$url = 'https://www.breakingbadapi.com/api/characters/2';

$arrContextOptions = array(
    "ssl" => array(
        "verify_peer"      => false,
        "verify_peer_name" => false,
    ),
);

$response = apiCall($url);

foreach ($response as $character) {
    echo "<pre>";
    print_r($character);
    echo "</pre>";

    $src       = $character['img'];
    $file_name = $character['name'];

    $image = file_get_contents($character['img'], false, stream_context_create($arrContextOptions));
    file_put_contents("img/$file_name.jpg", $image);
    // echo $image;
}

if (sendMail('arun0306.r@gmail.com')) {
    echo 'Email sent!';
} else {
    echo 'Unable to send email :_(';
}
